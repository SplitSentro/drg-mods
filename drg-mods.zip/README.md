# SplitSentro's DRG Mods

## Restart Mission
A mod that allows to restart missions and more.
Currently under developing. Early testing stage.

## ActorMonitor
A mod which is supposed to display information on top of enemies for testing purposes.
Currently on hold. As of now, you can press "~" to launch the selector, aim at the bug and then press Ctrl+"~" to start Monitor that shows only Status Effect and the number of instances for each actor (if it has the STE component).

To install, you'll need UE 4.27.2 and FSD-Template.

This is licensed under the terms of the MIT license.